-- MySQL dump 10.16  Distrib 10.1.9-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: sevenkeys
-- ------------------------------------------------------
-- Server version	10.1.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `ACCOUNT_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ACCOUNT_LOGIN` varchar(80) NOT NULL,
  `ACCOUNT_NAME` varchar(80) NOT NULL,
  `ACCOUNT_PASSWORD` varchar(80) NOT NULL,
  `ACCOUNT_URL` varchar(80) NOT NULL,
  `USER_ACCOUNTS` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ACCOUNT_ID`),
  KEY `FK_1viie4cni088r2y4nb45a1xcl` (`USER_ACCOUNTS`),
  CONSTRAINT `FK_1viie4cni088r2y4nb45a1xcl` FOREIGN KEY (`USER_ACCOUNTS`) REFERENCES `user` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'isabela.ilma@hotmail.com','Facebook','11','facebook.com.br',1);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `ADDRESS_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ADDRESS_CITY` varchar(80) NOT NULL,
  `ADDRESS_COUTRY` varchar(80) NOT NULL,
  `ADDRESS_NEIGHBORHOOD` varchar(80) NOT NULL,
  `ADDRESS_NUMBER` varchar(80) NOT NULL,
  `ADDRESS_STATE` varchar(80) NOT NULL,
  `ADDRESS_STREET` varchar(80) NOT NULL,
  `ADDRESS_ZIPCODE` varchar(80) NOT NULL,
  PRIMARY KEY (`ADDRESS_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'Taubaté','Brasil','Residencial Sítio Santo Antônio','1901','São Paulo','Avenida Doutor José Ortiz Patto','12072010');
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `LOGIN_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `LOGIN_PASSWORD` varchar(80) NOT NULL,
  `LOGIN_USERNAME` varchar(80) NOT NULL,
  PRIMARY KEY (`LOGIN_ID`),
  UNIQUE KEY `UK_5ja62iqb6cfvgis013kgqq80s` (`LOGIN_USERNAME`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'fatec','isabela.ilma');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone`
--

DROP TABLE IF EXISTS `phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phone` (
  `PHONE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PHONE_DDD` varchar(2) NOT NULL,
  `PHONE_PHONE` varchar(10) NOT NULL,
  `USER_PHONES` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`PHONE_ID`),
  KEY `FK_l4ldsuusxxnhxcb4epre347p2` (`USER_PHONES`),
  CONSTRAINT `FK_l4ldsuusxxnhxcb4epre347p2` FOREIGN KEY (`USER_PHONES`) REFERENCES `user` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone`
--

LOCK TABLES `phone` WRITE;
/*!40000 ALTER TABLE `phone` DISABLE KEYS */;
INSERT INTO `phone` VALUES (1,'12','991339372',1),(2,'12','991850800',1);
/*!40000 ALTER TABLE `phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `USER_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_NAME` varchar(200) NOT NULL,
  `USER_ADDRESS` bigint(20) DEFAULT NULL,
  `USER_LOGIN` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `UK_h029unq4qgmbvesub83df4vok` (`USER_NAME`),
  KEY `FK_p0ft960qn8rh9uixk8bvi19nw` (`USER_ADDRESS`),
  KEY `FK_pqi5acc6k4to4xj6rx68d6yvs` (`USER_LOGIN`),
  CONSTRAINT `FK_p0ft960qn8rh9uixk8bvi19nw` FOREIGN KEY (`USER_ADDRESS`) REFERENCES `address` (`ADDRESS_ID`),
  CONSTRAINT `FK_pqi5acc6k4to4xj6rx68d6yvs` FOREIGN KEY (`USER_LOGIN`) REFERENCES `login` (`LOGIN_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Isabela Ilma Gonçalves',1,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-03-02  8:16:29
