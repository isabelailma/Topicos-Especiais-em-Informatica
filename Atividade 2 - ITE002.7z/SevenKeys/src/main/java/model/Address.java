package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ADDRESS")
public class Address {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ADDRESS_ID")
	private Long id;
	
	@Column(name="ADDRESS_COUTRY", unique = false, length = 80, nullable = false)
	private String country;
	
	@Column(name="ADDRESS_STATE", unique = false, length = 80, nullable = false)
	private String state;
	
	@Column(name="ADDRESS_CITY", unique = false, length = 80, nullable = false)
	private String city;
	
	@Column(name="ADDRESS_NEIGHBORHOOD", unique = false, length = 80, nullable = false)
	private String neighborhood;
	
	@Column(name="ADDRESS_STREET", unique = false, length = 80, nullable = false)
	private String street;
	
	@Column(name="ADDRESS_NUMBER", unique = false, length = 80, nullable = false)
	private String number;
	
	@Column(name="ADDRESS_ZIPCODE", unique = false, length = 80, nullable = false)
	private String zipCode;
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getNeighborhood() {
		return neighborhood;
	}
	public void setNeighborhood(String neighborhood) {
		this.neighborhood = neighborhood;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
}