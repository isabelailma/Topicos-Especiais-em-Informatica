package ADS;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalculadoraTest {

	Double num1, num2, esperado;
	private Calculos calculadora;
	
	@Before
	public void iniciar() {
		calculadora = new Calculos();
		num1 = 10.00;
		num2 = 2.00;
		esperado = 0.00;
	}
	
	@Test
	public void somarTest() {
		esperado = 12.00;
		assertEquals(esperado, calculadora.somar(num1, num2));
	}
	
	@Test
	public void subtrairTest() {
		esperado = 8.00;
		assertEquals(esperado, calculadora.subtrair(num1, num2));
	}
	
	@Test
	public void dividirTest() {
		esperado = 5.00;
		assertEquals(esperado, calculadora.dividir(num1, num2));
	}
	
	@Test
	public void multiplicarTest() {
		esperado = 20.00;
		assertEquals(esperado, calculadora.multiplicar(num1, num2));
	}
	
	@After
	public void finalizar() {
		calculadora = null;
		num1 = null;
		num2 = null;
		esperado = null;
		System.gc();
	}
}