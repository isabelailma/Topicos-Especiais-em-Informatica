package ADS;

public class Calculos {
	
	public Double somar(Double num1, Double num2){
		return num1 + num2;
	}
	
	public Double subtrair(Double num1, Double num2){
		return num1 - num2;
	}

	public Double dividir(Double num1, Double num2){
		return num1 / num2;
	}

	public Double multiplicar(Double num1, Double num2){
		return num1 * num2;
	}
}