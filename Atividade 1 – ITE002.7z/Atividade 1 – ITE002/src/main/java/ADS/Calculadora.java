package ADS;

public class Calculadora {
	public static void main(String[] args) {
		Calculos calculos = new Calculos();
		
		Double num1 = 10.00;
		Double num2 = 2.00;
		
		System.out.println("Resultado = " + calculos.somar(num1, num2));
		System.out.println("Resultado = " + calculos.subtrair(num1, num2));
		System.out.println("Resultado = " + calculos.dividir(num1, num2));
		System.out.println("Resultado = " + calculos.multiplicar(num1, num2));
	}
}