package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ACCOUNT")
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ACCOUNT_ID")
	private Long id;
	
	@Column(name="ACCOUNT_NAME", unique = false, length = 80, nullable = false)
	private String name;
	
	@Column(name="ACCOUNT_URL", unique = false, length = 80, nullable = false)
	private String url;
	
	@Column(name="ACCOUNT_LOGIN", unique = false, length = 80, nullable = false)
	private String login;
	
	@Column(name="ACCOUNT_PASSWORD", unique = false, length = 80, nullable = false)
	private String password;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}