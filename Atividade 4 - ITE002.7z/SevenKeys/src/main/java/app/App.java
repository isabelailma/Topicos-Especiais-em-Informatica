package app;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import model.Account;
import model.Address;
import model.Login;
import model.Phone;
import model.User;

public class App {
	
	public static void main(String[] args) {
		
		// Cria um entity manager
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("sevenkeys");
		EntityManager manager = factory.createEntityManager();
		
		// Inser��o de Dados
		// Address
		Address address = new Address();
		address.setCountry("Brasil");
		address.setState("S�o Paulo");
		address.setCity("Taubat�");
		address.setNeighborhood("Residencial S�tio Santo Ant�nio");
		address.setStreet("Avenida Doutor Jos� Ortiz Patto");
		address.setNumber("1901");
		address.setZipCode("12072010");
		
		// Phones
		Set<Phone> phones = new HashSet<>();
		Phone phone1 = new Phone();
		phone1.setDdd("12");
		phone1.setPhone("991339372");
		
		Phone phone2 = new Phone();
		phone2.setDdd("12");
		phone2.setPhone("991850800");
		
		phones.add(phone1);
		phones.add(phone2);
		
		// Accounts
		Set<Account> accounts = new HashSet<>();
		Account account = new Account();
		account.setName("Facebook");
		account.setUrl("facebook.com.br");
		account.setLogin("isabela.ilma@hotmail.com");
		account.setPassword("11");
		
		accounts.add(account);
		
		// Login
		Login login = new Login();
		login.setUsername("isabela.ilma");
		login.setPassword("fatec");
		
		// User
		User user = new User();
		user.setLogin(login);
		user.setName("Isabela Ilma Gon�alves");
		user.setAddress(address);
		user.setPhones(phones);
		user.setAccounts(accounts);

		// Persistindo Dados no BD
		manager.getTransaction().begin();    
    	manager.persist(user);
    	manager.getTransaction().commit();
    	
    	// Atualiza Dados
    	manager.refresh(user);
    	
    	// Buscamos o usuario    	
    	Query query = manager.createQuery("select u from User u where u.name = :name");
    	query.setParameter("name", "Isabela Ilma Gon�alves");
    	
    	User userSearch = (User) query.getSingleResult();
    	
    	// Mostramos o Nome
    	System.out.println(userSearch.getName());
    	
    	// Mostramos o Login
    	System.out.println(userSearch.getLogin().getUsername());
    	
    	// Mostramos o Address
    	System.out.println(userSearch.getAddress().getNeighborhood());
    	
    	// Mostramos os Phones
    	for(Phone each: userSearch.getPhones()) {
    		System.out.println(each.getDdd() + each.getPhone());
    	}
    	
    	// Mostramos os Accounts
    	userSearch.getAccounts().forEach(each -> System.out.println(each.getName()));
    	
    	// Excluir Tudo
    	// A Ordem Importa, ou Teremos Erro por Causa das Chaves
    	manager.getTransaction().begin();    
    	//manager.remove(userSearch.getPhones());
    	for(Phone each: userSearch.getPhones()) {
    		manager.remove(each);
    	}
    	for(Account each: userSearch.getAccounts()) {
    		manager.remove(each);
    	}
    	
    	//manager.remove(userSearch);
    	manager.getTransaction().commit();
    	
    	manager.close();
    	factory.close();
	}
}