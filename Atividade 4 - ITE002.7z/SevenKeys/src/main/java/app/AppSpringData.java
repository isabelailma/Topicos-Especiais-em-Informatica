package app;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Account;
import model.Address;
import model.Login;
import model.Phone;
import model.User;
import repository.AccountRepository;
import repository.AddressRepository;
import repository.LoginRepository;
import repository.PhoneRepository;
import repository.UserRepository;

public class AppSpringData {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		// Recupera os repositorios | Spring Data Cria Beans Autom�tico
		AccountRepository accountRepository = (AccountRepository) context.getBean("accountRepository");
		AddressRepository addressRepository = (AddressRepository) context.getBean("addressRepository");
		LoginRepository loginRepository = (LoginRepository) context.getBean("loginRepository");
		PhoneRepository phoneRepository = (PhoneRepository) context.getBean("phoneRepository");
		UserRepository userRepository = (UserRepository) context.getBean("userRepository");

		// Inser��o de Dados
		// Address
		Address address = new Address();
		address.setCountry("Brasil");
		address.setState("S�o Paulo");
		address.setCity("Taubat�");
		address.setNeighborhood("Residencial S�tio Santo Ant�nio");
		address.setStreet("Avenida Doutor Jos� Ortiz Patto");
		address.setNumber("1901");
		address.setZipCode("12072010");

		// Phones
		Set<Phone> phones = new HashSet<>();
		Phone phone1 = new Phone();
		phone1.setDdd("12");
		phone1.setPhone("991339372");

		Phone phone2 = new Phone();
		phone2.setDdd("12");
		phone2.setPhone("991850800");

		phones.add(phone1);
		phones.add(phone2);

		// Accounts
		Set<Account> accounts = new HashSet<>();
		Account account = new Account();
		account.setName("Facebook");
		account.setUrl("facebook.com.br");
		account.setLogin("isabela.ilma@hotmail.com");
		account.setPassword("11");

		accounts.add(account);

		// Login
		Login login = new Login();
		login.setUsername("isabela.ilma");
		login.setPassword("fatec");

		// User
		User user = new User();
		user.setLogin(login);
		user.setName("Isabela Ilma Gon�alves");
		user.setAddress(address);
		user.setPhones(phones);
		user.setAccounts(accounts);

		userRepository.save(user);

		System.out.println("Id: " + user.getId());

		// Realiza varias consultas
		System.out.println("Resultado da Busca por Nome: " + userRepository.findByName("Isabela Ilma Gon�alves").getName());

		System.out.println("Resultado da Busca por Like: " + userRepository.findTop1ByNameContains("bela").getName());

		for (User each : userRepository.findByIdGreaterThan((long) 00)) {
			System.out.println("Usuarios Encontrados com Id Maior que 00: " + each.getName());
		}

		for (User each : userRepository.buscaUsuario("bela")) {
			System.out.println("Resultado da Busca por Like JPQL (Java Persistence Query Language): " + each.getName());
		}

		// Exclui usuario
		User delUser = userRepository.findTop1ByNameContains("bela");
		userRepository.delete(delUser);
	}
}