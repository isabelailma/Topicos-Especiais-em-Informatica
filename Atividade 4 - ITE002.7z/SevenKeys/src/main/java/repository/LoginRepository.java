package repository;

import org.springframework.data.repository.CrudRepository;

import model.Login;

public interface LoginRepository extends CrudRepository<Login, Long> {

}