package repository;

import org.springframework.data.repository.CrudRepository;

import model.Phone;

public interface PhoneRepository extends CrudRepository<Phone, Long> {

}