package app;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.User;

public class AppXmlEM {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		User user = (User) context.getBean("user");
		System.out.println(user.toString());

		// Cria um entity manager
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("sevenkeys");
		EntityManager manager = factory.createEntityManager();

		// Persistindo Dados no BD
		manager.getTransaction().begin();
		manager.persist(user);
		manager.getTransaction().commit();

		// Atualiza Dados
		manager.refresh(user);
		
		manager.close();
    	factory.close();
	}
}