package inject;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Phone;

@Configuration
@ComponentScan(value={"inject"})
public class InjectConfig {
	private static ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
	
	public static ApplicationContext getSpringContext(){
		return context;
	}

	@Bean(name={"phones"})
	public Set<Phone> getPhones(){
		Set<Phone> phones = new HashSet<>();
		
		Phone phone = (Phone) getSpringContext().getBean("phone");
		phones.add(phone);
		
		return phones;
	}
}