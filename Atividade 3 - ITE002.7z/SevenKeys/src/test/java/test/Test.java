package test;

import java.util.HashSet;
import java.util.Set;

import model.Account;
import model.Address;
import model.Login;
import model.Phone;
import model.User;

public class Test {

	public static void main(String[] args) {
		Address address = new Address();
		address.setCountry("Brasil");
		address.setState("S�o Paulo");
		address.setCity("Taubat�");
		address.setNeighborhood("Residencial S�tio Santo Ant�nio");
		address.setStreet("Avenida Doutor Jos� Ortiz Patto");
		address.setNumber("1901");
		address.setZipCode("12072010");
		
		Set<Phone> phones = new HashSet<>();
		Phone phone1 = new Phone();
		phone1.setDdd("12");
		phone1.setPhone("991339372");
		
		Phone phone2 = new Phone();
		phone2.setDdd("12");
		phone2.setPhone("991850800");
		
		phones.add(phone1);
		phones.add(phone2);
		
		Set<Account> accounts = new HashSet<>();
		Account account = new Account();
		account.setName("Facebook");
		account.setUrl("facebook.com.br");
		account.setLogin("isabela.ilma@hotmail.com");
		account.setPassword("11");
		
		accounts.add(account);
		
		Login login = new Login();
		login.setUsername("isabela.ilma");
		login.setPassword("fatec");
		
		User user = new User();
		user.setLogin(login);
		user.setName("Isabela Ilma Gon�alves");
		user.setAddress(address);
		user.setPhones(phones);
		user.setAccounts(accounts);
		
		System.out.println(user.getLogin() + "\n" + user.getName() + "\n" + user.getAddress() + "\n" + user.getPhones() + "\n" + user.getAccounts());
	}
}